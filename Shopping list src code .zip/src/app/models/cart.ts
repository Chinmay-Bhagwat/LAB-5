export class cart {
    product:string = '';
    quantity:number = 0;
    price:number = 0;
}